import { Component, OnInit } from '@angular/core';

const  heroList  = {
  "DVa": "D.Va",
  "Doomfist": "Doomfist",
  "Queen": "Junker Queen",
  "Orisa": "Orisa",
  "Reinhardt": "Reinhardt",
  "Roadhog": "Roadhog",
  "Sigma": "Sigma",
  "Winston": "Winston",
  "Ball": "Wrecking Ball",
  "Zarya": "Zarya",
  "Ashe": "Ashe",
  "Bastion": "Bastion",
  "Cassidy": "Cassidy",
  "Echo": "Echo",
  "Genji": "Genji",
  "Hanzo": "Hanzo",
  "Junkrat": "Junkrat",
  "Mei": "Mei",
  "Pharah": "Pharah",
  "Reaper": "Reaper",
  "Soldier": "Soldier: 76",
  "Sojourn": "Sojourn",
  "Sombra": "Sombra",
  "Symmetra": "Symmetra",
  "Torbjorn": "Torbjörn",
  "Tracer": "Tracer",
  "Widowmaker": "Widowmaker",
  "Ana": "Ana",
  "Baptiste": "Baptiste",
  "Brigitte": "Brigitte",
  "Kiriko": "Kiriko",
  "Lucio": "Lúcio",
  "Mercy": "Mercy",
  "Moira": "Moira",
  "Zenyatta": "Zenyatta"
}

const roles = {
  support: [
    "Ana",
    "Baptiste",
    "Brigitte",
    "Kiriko",
    "Lúcio",
    "Mercy",
    "Moira",
    "Zenyatta"
  ],
  dps: [
    "Ashe",
    "Bastion",
    "Cassidy",
    "Echo",
    "Genji",
    "Hanzo",
    "Junkrat",
    "Mei",
    "Pharah",
    "Reaper",
    "Soldier: 76",
    "Sojourn",
    "Sombra",
    "Symmetra",
    "Torbjörn",
    "Tracer",
    "Widowmaker"
  ],
  tank: [
    "D.Va",
    "Doomfist",
    "Junker Queen",
    "Orisa",
    "Reinhardt",
    "Roadhog",
    "Sigma",
    "Winston",
    "Wrecking Ball",
    "Zarya"
  ]
}
@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.scss']
})

export class PlayerComponent implements OnInit {

  constructor() {
    this.setRandomHero('dps');
  }

  classes = {tank: 'assets/tank.svg', support: 'assets/support.svg', dps: 'assets/dps.svg', any: 'assets/any.svg'};
  hero: string = '';

  ngOnInit(): void {
  }

  setRandomHero(role?: 'support' | 'tank' | 'dps'){
    if(role){
      this.hero = Object.values(roles[role])[Math.floor(Math.random() * Object.keys(roles[role]).length)];
    }else{
      this.hero = Object.values(heroList)[Math.floor(Math.random() * Object.keys(heroList).length)];
    }

  }

}
